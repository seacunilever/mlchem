# mlchem - cheminformatics library
# Copyright © 2025 as Unilever Global IP Limited

# Redistribution and use in source and binary forms, with or without modification,
# are permitted under the terms of the BSD-3 License, provided that the following conditions are met:

#     1. Redistributions of source code must retain the above copyright
#        notice, this list of conditions and the following disclaimer.
#
#     2. Redistributions in binary form must reproduce the above copyright
#        notice, this list of conditions and the following disclaimer in
#        the documentation and/or other materials provided with the distribution.
#
#     3. Neither the name of the copyright holder nor the names of its
#        contributors may be used to endorse or promote products derived
#        from this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS”
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
# GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
# STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

# You should have received a copy of the BSD-3 License along with mlchem.
# If not, see https://interoperable-europe.ec.europa.eu/licence/bsd-3-clause-new-or-revised-license .
# It is the responsibility of mlchem users to familiarise themselves with all dependencies and their associated licenses.

from typing import Literal, Iterable, Callable, Any
import logging
import pandas as pd
import numpy as np
from PIL import Image
from bokeh.models import DataTable
from bokeh.plotting import figure


# DRAWING #


def convert_size(
    size: tuple[float, float] | None = None,
    pixel_size: tuple[int, int] | None = None,
    dpi: int = 100
) -> tuple[int, int] | tuple[float, float]:
    """
    Convert between size in inches and size in pixels.

    Parameters
    ----------
    size : tuple of float, optional
        Size in inches as (width, height).

    pixel_size : tuple of int, optional
        Size in pixels as (width, height).

    dpi : int, default=100
        Dots per inch used for conversion.

    Returns
    -------
    tuple of int or tuple of float
        Converted size in pixels if `size` is provided, or in inches 
        if `pixel_size` is provided.
    """

    if size and pixel_size:
        raise ValueError("Provide either size or pixel_size, not both.")
    if not size and not pixel_size:
        raise ValueError("Either size or pixel_size must be provided.")

    if size:
        width_px = size[0] * dpi
        height_px = size[1] * dpi
        return int(width_px), int(height_px)

    if pixel_size:
        width_in = pixel_size[0] / dpi
        height_in = pixel_size[1] / dpi
        return width_in, height_in


def generate_random_rgb() -> tuple[float, float, float]:
    """
    Generate a random RGB color.

    Returns
    -------
    tuple of float
        A tuple of three floats representing an RGB color, with each 
        component in the range [0, 1].
    """

    import random
    return (random.uniform(0, 1),
            random.uniform(0, 1),
            random.uniform(0, 1))


def convert_rgb(
    rgb_tuple: tuple[int, int, int],
    mode: Literal['normalise', 'denormalise']
) -> tuple[float, float, float] | tuple[int, int, int]:
    """
    Convert RGB values between 0-255 and 0-1 ranges.

    Parameters
    ----------
    rgb_tuple : tuple of int
        RGB values in the form (R, G, B).

    mode : {'normalise', 'denormalise'}
        Conversion mode. 'normalise' converts from 0-255 to 0-1, 
        'denormalise' converts from 0-1 to 0-255.

    Returns
    -------
    tuple of float or tuple of int
        Converted RGB values.
    """

    if mode == 'normalise':
        return tuple(value / 255.0 for value in rgb_tuple)    # (0,1)
    elif mode == 'denormalise':
        return tuple(int(value * 255) for value in rgb_tuple)     # (0,255)
    else:
        raise ValueError("Mode must be either 'normalise' or 'denormalise'.")


def make_rgb_transparent(
    fg_rgb: tuple[float, float, float],
    bg_rgb: tuple[float, float, float] = (1.0, 1.0, 1.0),
    alpha: float = 0.5
) -> tuple[float, float, float]:
    """
Apply transparency to a foreground RGB color over a background color.

Parameters
----------
fg_rgb : tuple of float
    Foreground RGB color in the range [0, 1].

bg_rgb : tuple of float, optional
    Background RGB color in the range [0, 1]. Default is white 
    (1.0, 1.0, 1.0).

alpha : float, default=0.5
    Transparency level, where 0 is fully transparent and 1 is fully opaque.

Returns
-------
tuple of float
    RGB color after applying transparency.
"""

    result = [alpha * c1 + (1 - alpha) * c2 for
              c1, c2 in
              zip(fg_rgb, bg_rgb)]
    return result[0], result[1], result[2]


def visualise_colour(
    rgb_tuple: tuple[float, float, float]
) -> None:
    """
Display a single RGB color.

Parameters
----------
rgb_tuple : tuple of float
    RGB values in the range [0, 1].

Returns
-------
None
"""

    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(2, 2))
    ax.set_facecolor(rgb_tuple)
    ax.set_xticks([])
    ax.set_yticks([])
    plt.show()


def visualise_colour_grid(
    colour_dictionary: dict[str, tuple[float, float, float]],
    save: bool = False,
    filename: str = '',
    figsize: tuple[int, int] = (20, 20)
) -> None:
    """
Display a grid of RGB colors.

Parameters
----------
colour_dictionary : dict of str to tuple of float
    Dictionary mapping color names to RGB tuples.

save : bool, default=False
    Whether to save the figure.

filename : str, optional
    Filename to save the figure if `save` is True.

figsize : tuple of int, default=(20, 20)
    Size of the figure.

Returns
-------
None
"""

    import numpy as np
    import matplotlib.pyplot as plt

    # Calculate the number of rows and columns to display the colour grid
    num_colors = len(colour_dictionary)
    num_columns = int(np.ceil(np.sqrt(num_colors)))
    num_rows = int(np.ceil(num_colors / num_columns))

    # Create a figure with subplots
    fig, axes = plt.subplots(num_rows, num_columns, figsize=figsize)

    # Flatten the axes array for easy iteration
    axes = axes.flatten()

    # Loop through the colour dictionary and create a subplot for each colour
    for ax, (colour_name, rgb_tuple) in zip(axes, colour_dictionary.items()):
        ax.set_facecolor(rgb_tuple)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_title(colour_name, fontsize=12)

    # Hide any unused subplots
    for ax in axes[len(colour_dictionary):]:
        ax.axis('off')

    # Adjust layout to prevent overlap
    plt.tight_layout()
    if save:
        plt.savefig(filename)
    plt.show()


def show_png(data: bytes) -> Image.Image:
    """
Display a PNG image from binary data.

Parameters
----------
data : bytes
    Binary data of the PNG image.

Returns
-------
Image.Image
    PIL Image object.
"""

    import io

    bio = io.BytesIO(data)
    img = Image.open(bio)
    return img


def create_smooth_gradient_circle(
    radius: int,
    color: tuple[int, int, int],
    alpha: float
) -> Image.Image:
    """
Create a smooth gradient circle with transparency.

Parameters
----------
radius : int
    Radius of the circle.

color : tuple of int
    Base RGB color in the range [0, 255].

alpha : float
    Transparency level in the range [0, 1].

Returns
-------
Image.Image
    PIL Image object containing the gradient circle.
"""

    from PIL import ImageDraw

    diameter = radius * 2
    gradient = Image.new('RGBA', (diameter, diameter), (0, 0, 0, 0))
    draw = ImageDraw.Draw(gradient)

    for i in range(radius):
        current_alpha = int(255 * alpha * (1 - i / radius))
        draw.ellipse(
            (i, i, diameter - i, diameter - i),
            fill=color + (current_alpha,)
        )

    return gradient


# MISCELLANEOUS #


def coerce_log_level(level: int | str) -> int:
    """
Resolve a logging level name or integer into a numeric logging level.

Parameters
----------
level : int or str
    Logging level as integer (e.g. 20) or level name (e.g. 'INFO').

Returns
-------
int
    Numeric logging level.

Raises
------
ValueError
    If level is not a valid logging level name or integer.
"""

    if isinstance(level, int):
        return level

    if isinstance(level, str):
        level_map = logging.getLevelNamesMapping()
        key = level.upper()
        if key in level_map:
            return level_map[key]

    raise ValueError("'log_level' must be a valid logging level name or integer.")


class LogCapture:
    """
Configure mlchem pipeline logging with optional file persistence.

By default, mlchem functions emit INFO-level logs to console. Use LogCapture
to add file logging, change the log level, or silence console output.

Parameters
----------
log_level : int or str, default='INFO'
    Logging level threshold (e.g., 'INFO', 'DEBUG', 'WARNING').

to_console : bool, default=True
    Whether to print logs to console. Set False to log only to file.

to_file : str or None, default=None
    Optional file path to write logs to. If provided, logs are appended
    to the file as well as console (if to_console=True).

Attributes
----------
stream : StringIO
    In-memory buffer containing captured logs.

Examples
--------
>>> # Default: logs appear on console automatically
>>> sfs = SequentialForwardSelection(...)
>>> sfs.fit(X_train, y_train, X_test, y_test)
>>> # Output appears on console immediately

>>> # Optionally: capture to file + memory for inspection
>>> logs = LogCapture(to_file='pipeline.log')
>>> sfs.fit(X_train, y_train, X_test, y_test)
>>> print(logs.get_logs())  # View memory capture
>>> # Also check pipeline.log file

>>> # Silent mode: only to file
>>> logs = LogCapture(to_console=False, to_file='pipeline.log')
>>> sfs.fit(X_train, y_train, X_test, y_test)
"""

    def __init__(self, log_level: int | str | Literal['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'] = logging.INFO,
                 to_console: bool = True,
                 to_file: str | None = None) -> None:
        from io import StringIO

        self.to_console = to_console
        self.to_file = to_file
        self.level = coerce_log_level(log_level)
        self.stream = StringIO()
        self._memory_handler = None
        self._console_handler = None
        self._file_handler = None
        self._root_logger = logging.getLogger()
        self._original_level = self._root_logger.level
        self._original_handlers = list(self._root_logger.handlers)

        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%H:%M:%S'
        )

        # Set up memory handler
        self._memory_handler = logging.StreamHandler(self.stream)
        self._memory_handler.setLevel(self.level)
        self._memory_handler.setFormatter(formatter)
        self._root_logger.addHandler(self._memory_handler)
        self._root_logger.setLevel(self.level)

        # Set up console handler if requested
        if self.to_console:
            self._console_handler = logging.StreamHandler()
            self._console_handler.setLevel(self.level)
            self._console_handler.setFormatter(formatter)
            self._root_logger.addHandler(self._console_handler)

        # Set up file handler if requested
        if self.to_file:
            self._file_handler = logging.FileHandler(self.to_file, mode='a')
            self._file_handler.setLevel(self.level)
            self._file_handler.setFormatter(formatter)
            self._root_logger.addHandler(self._file_handler)

    def get_logs(self) -> str:
        """
Retrieve all captured logs from memory as a string.

Returns
-------
str
    Complete captured log output from in-memory buffer.
"""
        return self.stream.getvalue()

    def clear(self) -> None:
        """Clear captured logs from memory buffer."""
        self.stream.truncate(0)
        self.stream.seek(0)

    def stop(self) -> None:
        """Stop capturing logs and remove handlers."""
        if self._memory_handler:
            self._root_logger.removeHandler(self._memory_handler)
        if self._console_handler:
            self._root_logger.removeHandler(self._console_handler)
        if self._file_handler:
            self._file_handler.close()
            self._root_logger.removeHandler(self._file_handler)
        self._root_logger.setLevel(self._original_level)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.stop()


def start_logging(log_level: int | str | Literal['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'] = logging.INFO,
                  to_console: bool = True,
                  to_file: str | None = None) -> LogCapture:
    """
Configure mlchem pipeline logging with optional file persistence.

Convenience function to set up logging. Logs are emitted to console by
default; optionally also to a file for later inspection.

Parameters
----------
log_level : int or str, default='INFO'
    Logging level threshold (e.g., 'INFO', 'DEBUG', 'WARNING').

to_console : bool, default=True
    Whether to print logs to console.

to_file : str or None, default=None
    Optional file path to write logs to.

Returns
-------
LogCapture
    Log manager object with .get_logs() for memory inspection.

Examples
--------
>>> # Log to console + file
>>> logs = start_logging(to_file='pipeline.log')
>>> sfs.fit(X_train, y_train, X_test, y_test)
>>> print(logs.get_logs())  # Inspect memory

>>> # Log only to file (silent)
>>> logs = start_logging(to_console=False, to_file='pipeline.log')
>>> sfs.fit(X_train, y_train, X_test, y_test)
"""
    return LogCapture(log_level=log_level, to_console=to_console, to_file=to_file)


def validate_task_type(task_type: str) -> str:
    """
Validate task type used by ML helpers.

Parameters
----------
task_type : str
    Task kind.

Returns
-------
str
    The validated task type.

Raises
------
ValueError
    If task_type is not 'classification' or 'regression'.
"""

    if task_type not in ('classification', 'regression'):
        raise ValueError("'task_type' must be either 'classification' or 'regression'.")
    return task_type


def resolve_n_jobs(n_jobs: int) -> int:
    """
Normalize n_jobs values used by parallel wrappers.

Parameters
----------
n_jobs : int
    Requested number of workers. -1 means all CPUs.

Returns
-------
int
    Resolved positive worker count.

Raises
------
ValueError
    If n_jobs is not -1 or a positive integer.
"""

    import os

    if n_jobs == -1:
        return os.cpu_count() or 1
    if n_jobs < -1 or n_jobs == 0:
        raise ValueError("'n_jobs' must be -1 or a positive integer.")
    return n_jobs


def suppress_warnings() -> None:
    """
Suppress all warnings in the current Python session.

Returns
-------
None
"""

    import warnings
    warnings.filterwarnings("ignore")


def standardise_path(path: str) -> str:
    """
Convert a Windows-style path to a standardised format.

Parameters
----------
path : str
    Path string with backslashes.

Returns
-------
str
    Path string with forward slashes.
"""

    return path.replace("\\", "/")




def generate_cartesian_product(*lists: Iterable) -> list[list]:
    """
Generate the Cartesian product of multiple lists.

Produces all combinations where each combination contains exactly one element
from each input list. For example, given lists A, B, and C, returns all tuples
(a, b, c) where a ∈ A, b ∈ B, c ∈ C.

Parameters
----------
*lists : iterable
    Two or more iterables (lists, tuples, etc.) to combine.

Returns
-------
list of list
    List of combinations, where each combination is a list containing
    one element from each input list.

Raises
------
ValueError
    If fewer than two lists are provided, or if any list is empty.

TypeError
    If any argument is not a list or tuple.

Examples
--------
>>> generate_cartesian_product([1, 2], ['a', 'b'])
[[1, 'a'], [1, 'b'], [2, 'a'], [2, 'b']]

>>> generate_cartesian_product([True, False], ['x', 'y'], [1])
[[True, 'x', 1], [True, 'y', 1], [False, 'x', 1], [False, 'y', 1]]
"""
    from itertools import product

    # Validate input
    if not lists or len(lists) < 2:
        raise ValueError("At least two lists are required.")
    
    for idx, lst in enumerate(lists, start=1):
        if not isinstance(lst, (list, tuple)):
            raise TypeError(f"Argument {idx} must be a list or tuple.")
        if len(lst) == 0:
            raise ValueError(f"List {idx} is empty; cannot generate combinations.")
    
    # Generate all combinations and convert tuples to lists
    return [list(combo) for combo in product(*lists)]


def disable_estimator_parallelization(estimator):
    """
Disable internal parallelization in sklearn estimators to avoid nested parallelization.

When wrapper-level parallelization (ThreadPoolExecutor) is used, individual
estimators should disable internal job parallelism to prevent nested
parallelism warnings and avoid thread conflicts.

Parameters
----------
estimator : object
    A scikit-learn estimator object.

Returns
-------
object
    The estimator with internal parallelization disabled if applicable,
    otherwise unchanged.
"""
    if hasattr(estimator, 'n_jobs'):
        try:
            estimator.set_params(n_jobs=None)
        except (ValueError, TypeError):
            try:
                estimator.set_params(n_jobs=1)
            except (ValueError, TypeError):
                pass  # Estimator doesn't support set_params or n_jobs parameter
    return estimator


def generate_combination_cascade(
    elements: Iterable,
    n: int
) -> Iterable[Iterable]:
    """
Generate all combinations of elements from size 1 to n.

Parameters
----------
elements : iterable
    Input elements to combine.

n : int
    Maximum size of combinations.

Returns
-------
list of list
    List of combinations of elements.
"""

    from itertools import combinations

    cols = [list(a) for a in combinations(elements, 1)]
    for i in range(2, n + 1):
        cols += [list(a) for a in combinations(elements, i)]
    return cols


def count_features(list_features: Iterable[str]) -> int:
    """
Count the total number of features, including interaction terms.

Parameters
----------
list_features : iterable of str
    List of feature names, possibly including interaction terms.

Returns
-------
int
    Total number of features.

Example
-------
>>> count_features(['a', 'b', 'a b'])
4
>>> count_features(['a', 'a b', 'c^2'])
5
>>> count_features(['a', 'b', 'c', 'c a', 'c b^2', 'a^3'])
11
"""
    import numpy as np

    flattened_list = np.hstack([a.split(' ') for a in list_features])
    count_degree_1 = len(flattened_list)
    count_degree_2 = sum('^2' in s for s in flattened_list)
    count_degree_3 = sum('^3' in s for s in flattened_list)
    final_count = count_degree_1 + count_degree_2 + (2 * count_degree_3)
    return final_count


def loadingbar(
    count: int,
    total: int,
    size: int
) -> None:
    """
Display a loading bar to indicate progress.

Parameters
----------
count : int
    Current iteration.

total : int
    Total number of iterations.

size : int
    Length of the loading bar.

Returns
-------
None
"""
    import sys

    percent = float(count) / float(total)
    filled_length = int(size * percent)
    bar = '=' * filled_length + ' ' * (size - filled_length)
    sys.stdout.\
        write(
            f"\r{str(count).rjust(3, '0')}/{str(total).rjust(3, '0')} [{bar}]"
            )
    sys.stdout.flush()


def create_progressive_column_names(
    serial_name: str,
    n: int
) -> list[str]:
    """
Generate a list of sequential column names.

Parameters
----------
serial_name : str
    Base name for the columns.

n : int
    Number of columns to generate.

Returns
-------
list of str
    List of column names.
"""

    return [f"{serial_name}{i + 1}" for i in range(n)]


def try_except(
    func: Callable[[], Any],
    exc: Any = None,
    exceptions: type[BaseException] | tuple[type[BaseException], ...] = Exception,
) -> Any:
    """
Execute a function and return its result or a fallback value on exception.

Parameters
----------
func : callable
    Function to execute.

exc : any, optional
    Value to return if an exception occurs. Default is None.

exceptions : exception type or tuple of exception types, optional
    Exception types to catch. Default catches Exception.

Returns
-------
any
    Result of the function or fallback value.

Raises
------
TypeError
    If `exceptions` is not an exception class or tuple of exception classes.
"""

    if isinstance(exceptions, tuple):
        if not exceptions or not all(
            isinstance(ex, type) and issubclass(ex, BaseException)
            for ex in exceptions
        ):
            raise TypeError(
                "'exceptions' must be an exception type or tuple of exception types."
            )
    elif not (isinstance(exceptions, type) and issubclass(exceptions, BaseException)):
        raise TypeError(
            "'exceptions' must be an exception type or tuple of exception types."
        )

    try:
        return func()
    except exceptions:
        return exc


def find_all_occurrences(
    text: str,
    substring: str
) -> list[int]:
    """
Find all starting indices of a substring in a text.

Parameters
----------
text : str
    Text to search.

substring : str
    Substring to find.

Returns
-------
list of int
    List of starting indices where the substring occurs.
"""

    indices = []
    start = 0
    while True:
        index = text.find(substring, start)
        if index == -1:
            break
        indices.append(index)
        start = index + 1
    return indices


def reset_string(input_string: str) -> str:
    """
Remove punctuation and convert a string to lowercase.

Parameters
----------
input_string : str
    Input string.

Returns
-------
str
    Processed string.
"""

    punctuation = '''"!()-[]{};:'\\, <>./?@#$%^&*_~'''
    for ch in input_string:
        if ch in punctuation:
            input_string = input_string.replace(ch, "")
    return input_string.lower()


def insert_string_piece(
    text: str,
    substring: str,
    index: int
) -> str:
    """
Insert a substring into a string at a specified index.

Parameters
----------
text : str
    Original string.

substring : str
    Substring to insert.

index : int
    Index at which to insert the substring.

Returns
-------
str
    Modified string.

Raises
------
ValueError
    If index is less than 0.
"""

    if index > 0:
        return text[:index + 1] + substring + text[index + 1:]
    elif index < 0:
        raise ValueError('index must be at least 0')
    elif index == 0:
        return substring + text


def flatten(args: Any) -> tuple[Any, ...]:
    """
Flatten a nested structure into a single tuple.

Parameters
----------
args : Any
    The nested structure to flatten.

Returns
-------
tuple
    A flattened tuple containing all elements.
"""

    if isinstance(args, (str, bytes, bytearray)):
        return (args,)

    try:
        iter(args)
        final = []
        for arg in args:
            final += flatten(arg)
        return tuple(final)
    except TypeError:
        return (args,)


def process_custom_string(
    s: str,
    target_substring: str,
    replacement_list: list[str],
    separator: str = ';'
) -> str:
    """
Process a string by replacing a target substring with elements from a 
list and formatting the result.

Parameters
----------
s : str
    The original string.

target_substring : str
    The substring to replace.

replacement_list : list of str
    List of strings to replace the target substring.

separator : str, default=';'
    Separator used in formatting the result.

Returns
-------
str
    The processed and formatted string.
"""

    import string

    # Replace target_substring with respective strings from the list
    for replacement in replacement_list:
        s = s.replace(target_substring, replacement, 1)

    # Remove punctuation characters
    s = ''.join(char for char in s if char not in string.punctuation)

    # Replace all digits with the separator
    s = ''.join(separator if char.isdigit() else char for char in s)

    # Replace all remaining non-punctuation characters with the separator,
    # except for the replacements
    result = []
    replacement_index = 0
    i = 0
    while i < len(s):
        if (replacement_index < len(replacement_list) and
                s[i:i+len(replacement_list[replacement_index])] ==
                replacement_list[replacement_index]):
            if result and result[-1] != separator:
                result.append(separator)
            result.append(replacement_list[replacement_index])
            i += len(replacement_list[replacement_index])
            replacement_index += 1
        else:
            result.append(separator if s[i].isalnum() else s[i])
            i += 1

    return ''.join(result)


def sort_list_by_other_list(list_1: list,
                            list_2: list[int | float]
                            ) -> tuple[list[str], list[int | float]]:
    """
Sort one list based on the absolute values of another list.

Parameters
----------
list_1 : list
    List of elements to sort.

list_2 : list of int or float
    List of values used to determine sort order.

Returns
-------
tuple of list
    Sorted list of elements and corresponding sorted values.
"""


    combined = list(zip(list_1, list_2))
    sorted_combined = sorted(combined, key=lambda x: abs(x[1]), reverse=True)
    
    sorted_elements = [x[0] for x in sorted_combined]
    sorted_values = [x[1] for x in sorted_combined]
    
    return (sorted_elements, sorted_values)


def merge_dicts_with_duplicates(
    dict1: dict[str, Any],
    dict2: dict[str, Any]
) -> dict[str, Any]:
    """
Merge two dictionaries, renaming duplicate keys from the second dictionary.

Parameters
----------
dict1 : dict of str to Any
    First dictionary.

dict2 : dict of str to Any
    Second dictionary.

Returns
-------
dict of str to Any
    Merged dictionary with unique keys.
"""

    # Start with a copy of the first dictionary
    merged_dict = dict(dict1)

    for key, value in dict2.items():
        if key in merged_dict:
            # If the key already exists,
            # create a new key with '_duplicate' suffix
            new_key = f"{key}_duplicate"
            # Ensure the new key is unique
            while new_key in merged_dict:
                new_key += "_duplicate"
            merged_dict[new_key] = value
        else:
            merged_dict[key] = value

    return merged_dict


def add_inchi_to_dataframe(
    df: pd.DataFrame,
    loc: int,
    smiles_column_name: str
) -> pd.DataFrame:
    """
Add an InChI column to a DataFrame by converting SMILES strings.

Parameters
----------
df : pandas.DataFrame
    Input DataFrame.

loc : int
    Column index to insert the InChI column.

smiles_column_name : str
    Name of the column containing SMILES strings.

Returns
-------
pandas.DataFrame
    DataFrame with the added InChI column.
"""

    from rdkit import Chem

    inchi_list = [Chem.MolToInchi(Chem.MolFromSmiles(s))
                  for s in df[smiles_column_name]]
    df.insert(loc, 'INCHI', inchi_list)
    return df


def identify_df_duplicates(
    df: pd.DataFrame,
    column_name: str,
    keep: Literal['first', 'last'] = 'last'
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
Identify and separate duplicate rows in a DataFrame based on a column.

Parameters
----------
df : pandas.DataFrame
    Input DataFrame.

column_name : str
    Column to check for duplicates.

keep : {'first', 'last'}, default='last'
    Which duplicate to keep.

Returns
-------
tuple of pandas.DataFrame
    Cleaned DataFrame and DataFrame of removed duplicates.

Raises
------
KeyError
    If `column_name` does not exist in `df`.

ValueError
    If `keep` is not 'first' or 'last'.
"""

    if column_name not in df.columns:
        raise KeyError(f"Column '{column_name}' not found in DataFrame.")

    if keep not in ('first', 'last'):
        raise ValueError("'keep' must be either 'first' or 'last'.")

    cleaned_df = df.drop_duplicates(subset=column_name, keep=keep)
    duplicates_removed = df.loc[~df.index.isin(cleaned_df.index)]
    return cleaned_df, duplicates_removed


def create_structure_files(
    df: pd.DataFrame,
    structure_column_name: str,
    folder_name: str
) -> None:
    """
Create PNG structure files for molecules in a DataFrame.

Parameters
----------
df : pandas.DataFrame
    Input DataFrame.

structure_column_name : str
    Column containing molecular structures.

folder_name : str
    Folder to save the PNG images.

Returns
-------
None
"""


    import os
    import shutil
    from mlchem.chem.manipulation import create_molecule
    from rdkit import Chem
    from rdkit.Chem import Draw

    # Create the folder, removing it first if it already exists
    if os.path.exists(folder_name):
        shutil.rmtree(folder_name)
    os.mkdir(folder_name)

    for i, s in enumerate(df[structure_column_name]):
        try:
            mol = create_molecule(s)
            filename = f'{folder_name}/{i}.png'
            Draw.MolToFile(mol, filename)
        except Exception:
            # If molecule does not get read properly,
            # create a placeholder image
            filename = f'{folder_name}/{i}.png'
            Draw.MolToFile(Chem.MolFromSmarts('*'), filename)


def prepare_dataframe(
    df: pd.DataFrame,
    dir_name: str
) -> pd.DataFrame:
    """
Add a 'MOLFILE' column to a DataFrame with sorted file paths.

Parameters
----------
df : pandas.DataFrame
    Input DataFrame.

dir_name : str
    Directory containing the files.

Returns
-------
pandas.DataFrame
    DataFrame with the added 'MOLFILE' column.
"""

    import os

    # Sort list of files based on last modification time in ascending order
    list_of_files = filter(
        lambda x: os.path.isfile(os.path.join(dir_name, x)),
        os.listdir(dir_name)
    )
    sorted_files = sorted(
        list_of_files,
        key=lambda x: os.path.getmtime(os.path.join(dir_name, x))
    )
    file_paths = [os.path.join(dir_name, f) for f in sorted_files]
    df.insert(2, 'MOLFILE', file_paths)

    return df


def prepare_datatable(
    df: pd.DataFrame,
    height: int = 500,
    width: int = int(650 / 0.75)
) -> DataTable:
    """
Create a Bokeh DataTable from a DataFrame.

Parameters
----------
df : pandas.DataFrame
    Input DataFrame.

height : int, default=500
    Height of the DataTable.

width : int, default=int(650 / 0.75)
    Width of the DataTable.

Returns
-------
bokeh.models.DataTable
    Bokeh DataTable object.

Raises
------
KeyError
    If required core columns are missing from the DataFrame.
"""

    from bokeh.models import ColumnDataSource, TableColumn

    required_columns = ['DIM_1', 'DIM_2', 'SMILES', 'MOLFILE', 'NAME', 'NAME_SHORT']
    missing_columns = [column for column in required_columns if column not in df.columns]
    if missing_columns:
        raise KeyError(f"Missing required columns: {missing_columns}")

    source = ColumnDataSource(df)
    columns = [
        TableColumn(field='DIM_1', title='DIM_1'),
        TableColumn(field='DIM_2', title='DIM_2'),
        TableColumn(field='SMILES', title='SMILES'),
        TableColumn(field='MOLFILE', title='MOLFILE'),
        TableColumn(field='NAME', title='NAME'),
        TableColumn(field='NAME_SHORT', title='NAME_SHORT'),
    ]

    if 'METADATA' in df.columns:
        columns.append(TableColumn(field='METADATA', title='METADATA'))

    return DataTable(source=source, columns=columns,
                     height=height, width=width)


def compute_alpha(size: int) -> float:
    """
Compute transparency value based on sample size.

Parameters
----------
size : int
    Sample size.

Returns
-------
float
    Computed alpha value.

Raises
------
ValueError
    If size is negative.
"""

    if size < 0:
        raise ValueError("'size' must be a non-negative integer.")

    if size < 100:
        alpha = 0.95
    elif size < 300:
        alpha = 0.9
    elif size < 800:
        alpha = 0.8
    elif size < 2000:
        alpha = 0.5
    else:
        alpha = 0.2
    return alpha


def size_ratio(
    size1: int,
    size2: int
) -> float:
    """
Compute a ratio based on the relative sizes of two values.

Parameters
----------
size1 : int
    First size.

size2 : int
    Second size.

Returns
-------
float
    Computed ratio.

Raises
------
ValueError
    If either size is negative or both sizes are zero.
"""

    if size1 < 0 or size2 < 0:
        raise ValueError("'size1' and 'size2' must be non-negative.")

    if size1 + size2 == 0:
        raise ValueError("'size1' and 'size2' cannot both be zero.")

    return 1 - ((size1 / (size1 + size2)) / 2)


def bokeh_plot(
    p: figure,
    classnames: list[str],
    dict_datatables: dict[str, DataTable]
) -> None:
    """
Display a Bokeh plot with associated DataTables.

Parameters
----------
p : bokeh.plotting.Figure
    Bokeh plot to display.

classnames : list of str
    List of class names.

dict_datatables : dict of str to DataTable
    Mapping of class names to DataTables.

Returns
-------
None
"""

    import bokeh.plotting as bp

    tables = [dict_datatables[classname] for classname in classnames]
    bp.show(bp.column(p, *tables))


def create_mask(
    array: np.ndarray,
    lower: float | int,
    upper: float | int
) -> np.ndarray:
    """
Create a boolean mask for values within a specified range.

Parameters
----------
array : numpy.ndarray
    Input array.

lower : float or int
    Lower bound.

upper : float or int
    Upper bound.

Returns
-------
numpy.ndarray
    Boolean mask array.
"""

    return (array <= upper) & (array > lower)


def assign_sign(x: float | int) -> str:
    """
Return the sign of a number as '+' or '-'.

Parameters
----------
x : float or int
    Input value.

Returns
-------
str
    '+' if x is non-negative, '-' otherwise.
"""

    return '+' if x >= 0 else '-'


def normalise_iterable(
    values: Iterable[float | int]
) -> list[float]:
    """
Normalise values in an iterable so that the maximum absolute value is 1.

Parameters
----------
values : iterable of float or int
    Iterable of numerical values.

Returns
-------
list of float
    Normalised values.
"""

    import math

    values_list = list(values)
    if not values_list:
        return []

    max_abs_weight = max(math.fabs(v) for v in values_list)

    if max_abs_weight > 0:
        return [v / max_abs_weight for v in values_list]
    return values_list


# DESCRIPTORS #


def dfs_to_excel(file_name: str,
                 dfs: Iterable[pd.DataFrame],
                 sheet_names: Iterable[str]) -> None:
    """
Write multiple DataFrames to an Excel file, each on a separate sheet.

Parameters
----------
file_name : str
    Name of the Excel file.

dfs : iterable of pandas.DataFrame
    DataFrames to write.

sheet_names : iterable of str
    Names of the sheets.

Returns
-------
None
"""

    with pd.ExcelWriter(file_name) as writer:
        for desc_df, sheet_name in zip(dfs, sheet_names):
            desc_df.to_excel(writer, sheet_name=sheet_name, index=True)
